# SimpleMatchmaker

Server - run it with no arguments, and it will run on default port 19601. Pass a different port as an optional argument if you want
If you forward ports, you can run it on your computer and it will be reachable to the wider internet

Client - simple example app for using the ServerConnection object and connecting to the server 
